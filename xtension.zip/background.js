chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    const targetURLs = ["x.com", "twitter.com"];
    if (changeInfo.status === 'complete' && targetURLs.some(url => tab.url.includes(url))) {
        createSoundHtml();
    }
});

function createSoundHtml(){
    chrome.offscreen.createDocument({
        url: chrome.runtime.getURL('audio.html'),
        reasons: ['AUDIO_PLAYBACK'],
        justification: 'notification',
    });
}
